import requests
import json
import time
from typing import List, Dict, Any, Callable, Optional

now = time.time()

class Update:
    def __init__(self, message_data: Dict[str, Any], chat_id: str, client: 'Client'):
        self.text = message_data.get("text", "")
        self.message_id = message_data.get("message_id", None)
        self.sender_id = message_data.get("sender_id", None)
        self.chat_id = chat_id
        self.raw = message_data
        self._client = client

    def reply(self, text: str):
        url = f"https://botapi.rubika.ir/v3/{self._client.token}/sendMessage"
        data = {
            "chat_id": self.chat_id,
            "text": text,
            "reply_to_message_id": self.message_id
        }
        try:
            resp = requests.post(url, json=data, timeout=10)
            jsn = resp.json()
            if resp.status_code == 200:
                if jsn.get("status") != "OK":
                    return resp.text
                return jsn
            return resp.text
        except Exception as e:
            return f"❌ Error in reply: {e}"


class Client:
    def __init__(self, token: str):
        self.token = token
        self.handlers = []
        self.command_handlers = {}
        jsn = self._request("getMe", {})
        if isinstance(jsn, dict) and jsn.get("status") != "INVALID_ACCESS":
            self.username = jsn["data"]["bot"]["username"]
            print(f"Bot started successfully✅ @{self.username}\nLibrary developer channel @RubiBotLibrary")
        else:
            raise ValueError(f"❌ Invalid token or connection issue: {jsn}")

    def _request(self, method: str, data: dict, headers: dict = None):
        url = f"https://botapi.rubika.ir/v3/{self.token}/{method}"
        try:
            response = requests.post(url, json=data, headers=headers, timeout=15)
            jsn = response.json()
            if response.status_code == 200 and jsn.get("status") == "OK":
                return jsn
            return {"error": response.text, "status": "FAILED"}
        except Exception as e:
            return {"error": str(e), "status": "EXCEPTION"}

    def send_text(self, chat_id: str, text: str, message_id: str = None):
        data = {"chat_id": chat_id, "text": text}
        if message_id is not None:
            data["reply_to_message_id"] = message_id
        return self._request("sendMessage", data)

    def on_message(self, filter: str = None) -> Callable:
        def decorator(func: Callable) -> Callable:
            self.handlers.append({
                "func": func,
                "filter": filter
            })
            return func
        return decorator

    def command(self, cmd: str) -> Callable:
        def decorator(func: Callable) -> Callable:
            self.command_handlers[cmd] = func
            return func
        return decorator

    def process_update(self, update: Update):
        text = update.text.strip()
        if text.startswith("/"):
            cmd = text.split()[0].lower()
            if cmd in self.command_handlers:
                try:
                    self.command_handlers[cmd](update)
                except Exception as e:
                    print(f"❗ Error in command handler {cmd}: {e}")
                return
        for handler in self.handlers:
            filt = handler["filter"]
            func = handler["func"]
            if filt is None or (
                filt == "private" and update.chat_id.startswith("b") or
                filt == "group" and update.chat_id.startswith("g") or
                filt == "channel" and update.chat_id.startswith("c")
            ):
                try:
                    func(update)
                except Exception as e:
                    print(f"❗ Error in message handler: {e}")

    def run(self, limit=100, poll_interval=0.1):
        offset_id = None
        last_message_id = None
        while True:
            try:
                data = {"limit": limit}
                if offset_id:
                    data["offset_id"] = offset_id
                result = self._request("getUpdates", data)
                if not isinstance(result, dict) or "data" not in result:
                    time.sleep(poll_interval)
                    continue
                updates = result["data"].get("updates", [])
                offset_id = result["data"].get("next_offset_id", offset_id)
                if not updates:
                    time.sleep(poll_interval)
                    continue
                for update in updates:
                    new_msg = update.get("new_message", {})
                    chat_id = update.get("chat_id")
                    message_id = new_msg.get("message_id")
                    tim = int(new_msg.get("time", 0))
                    if tim >= now and message_id != last_message_id:
                        last_message_id = message_id
                        upd = Update(new_msg, chat_id, client=self)
                        self.process_update(upd)
            except Exception as e:
                print(f"❗ Error in polling loop: {e}")
                time.sleep(1)
                continue
