from setuptools import setup, find_packages

setup(
    name="RubiBot",
    version="1.0.0",
    author="YourName",
    author_email="you@example.com",
    description="Rubika Bot API Python Library",
    packages=find_packages(),
    install_requires=["requests"],
    python_requires=">=3.7",
)
